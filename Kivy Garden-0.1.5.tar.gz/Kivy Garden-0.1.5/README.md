garden
======

The kivy garden installation script, split into its own package for convenient use in buildozer.

Licenses
========
Garden is released under the terms of the MIT License. Please refer to the LICENSE file.
